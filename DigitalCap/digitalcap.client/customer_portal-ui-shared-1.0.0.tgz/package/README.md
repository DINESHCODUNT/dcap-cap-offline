# Customer Portal Shared UI
This project aim to support components, utilities used in  Engineering Portal UI and maybe other projects. 

### Installation
- Run `yarn install`

### Starting development (via storybook)
- Run `yarn storybook` will start storybook server

### Testing
- Run `yarn test` will run all tests

### Linting
- Run `yarn lint` will run all linting 

### Generate component
- Run `yarn generate:component` will generate component
